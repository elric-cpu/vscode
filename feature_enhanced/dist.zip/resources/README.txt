This folder is served statically.

Replace these placeholder PDFs with the final versions:
- public/resources/home-maintenance-recordbook.pdf
- public/resources/home-restoration-resource-guide.pdf

Links in the site expect:
- /resources/home-maintenance-recordbook.pdf
- /resources/home-restoration-resource-guide.pdf
